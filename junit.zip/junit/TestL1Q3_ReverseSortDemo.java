import org.junit.AfterClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

public class TestL1Q3_ReverseSortDemo {

    private static double grade = 0.0;

    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // 1 seconds max per method tested



    @AfterClass
    public static void afterClass() {

        System.out.println(TestUtils.DIV);
        
        System.out.println("Grade for Q3_ReverseSortDemo (out of possible 1.0): " + grade);
        
        System.out.println(TestUtils.DIV);
        
    }

    @Test
    public void testQ3ReverseSortDemo() {

        char[] unordered = new char[] {'x', 'a', 'c', 'm', 'r', 'p'};
        
        char[] ordered = new char[] {'x', 'r', 'p', 'm', 'c', 'a'};
        
        Q3_ReverseSortDemo.reverseSort(unordered);
        
        assertArrayEquals("Could not reverse sort {'x', 'a', 'c', 'm', 'r', 'p'}.", ordered, unordered);
        
        grade += 0.5;
        
    }

    @Test
    public void testQ3ReverseSortDemoSorted() {

        char[] unordered = new char[] {'z', 'r', 'p', 'c', 'a'};
        
        char[] ordered = new char[] {'z', 'r', 'p', 'c', 'a'};
        
        Q3_ReverseSortDemo.reverseSort(unordered);
        
        assertArrayEquals("Could not reverse sort {'z', 'r', 'p', 'c', 'a'}.", ordered, unordered);
        
        grade += 0.25;
        
    }

    @Test
    public void testQ3ReverseSortDemoBlank() {

        char[] unordered = new char[] {};
        
        char[] ordered = new char[] {};
        
        Q3_ReverseSortDemo.reverseSort(unordered);
        
        assertArrayEquals("Could not reverse the empty array {}.", ordered, unordered);
        
        grade += 0.25;
        
    }

    public static void main(String[] args) {

        TestUtils.runClass(TestL1Q3_ReverseSortDemo.class);
        
    }

}
