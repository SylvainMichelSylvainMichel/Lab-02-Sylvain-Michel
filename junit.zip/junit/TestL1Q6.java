import org.junit.AfterClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

public class TestL1Q6 {

    private static final double DELTA = 0.00001;
        
    private static double grade = 0.0;

    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // 1 seconds max per method tested

    @AfterClass
    public static void afterClass() {
    
        System.out.println(TestUtils.DIV);
    
        System.out.println("Grade for Q6 (out of possible 2.0): " + grade);
    
        System.out.println(TestUtils.DIV);
    }

    @Test
    public void testQ6Average() {

        double[] sampleGradesFloat = {12.3, 50.0, 95.0, 68.0, 80.0, 90.5, 93.2, 99.9, 88.0, 72.0};
        double avg = Q6.calculateAverage(sampleGradesFloat);
        
        assertEquals("Wrong average for array {12.3, 50.0, 95.0, 68.0, 80.0, 90.5, 93.2, 99.9, 88.0, 72.0}.", 74.89, avg, DELTA);
        
        grade += 0.25;

    }

    @Test
    public void testQ6Average2() {

        double[] sampleGradesFloat = {95.5, 35.5, 52.5, 64.5, 45.0};
        
        double avg = Q6.calculateAverage(sampleGradesFloat);
        
        assertEquals("Wrong average for array {95.5, 35.5, 52.5, 64.5, 45.0}.", 58.6, avg, DELTA);
        
        grade += 0.25;
        
    }


    @Test
    public void testQ6NumberFailed() {

        double[] sampleGradesFloat =  {12.3, 57.0, 95.0, 18.0, 85.0, 82.5, 93.2, 99.9, 88.0, 70.0};
        
        int num_failed = Q6.calculateNumberFailed(sampleGradesFloat);
        
        assertEquals("Wrong number of failed for array {12.3, 57.0, 95.0, 18.0, 85.0, 82.5, 93.2, 99.9, 88.0, 70.0}.", 2, num_failed, DELTA);
        
        grade += 0.25;
        
    }

    @Test
    public void testQ6NumberFailed2() {

        double[] sampleGradesFloat = {95.5, 55.5, 52.5, 54.5, 65.0};
        
        int num_failed = Q6.calculateNumberFailed(sampleGradesFloat);
        
        assertEquals("Wrong number of failed for array {95.5, 55.5, 52.5, 54.5, 65.0}.", 0, num_failed, DELTA);
        
        grade += 0.25;
        
    }

    @Test
    public void testQ6NumberPassed() {

        double[] sampleGradesFloat = {12.3, 57.0, 95.0, 38.0, 85.0, 22.5, 93.2, 99.9, 88.0, 70.0};
            
        int num_passed = Q6.calculateNumberPassed(sampleGradesFloat);
            
        assertEquals("Wrong number of passed for array {12.3, 57.0, 95.0, 38.0, 85.0, 22.5, 93.2, 99.9, 88.0, 70.0}.", 7, num_passed, DELTA);
            
        grade += 0.25;

    }

    @Test
    public void testQ6NumberPassed2() {

        double[] sampleGradesFloat = {95.5, 35.5, 52.5, 64.5, 45.0};
        
        int num_passed = Q6.calculateNumberPassed(sampleGradesFloat);
        
        assertEquals("Wrong number of passed for array {95.5, 35.5, 52.5, 64.5, 45.0}.", 3, num_passed, DELTA);
        
        grade += 0.25;
        
    }

    @Test
    public void testQ6MedianInEvenLengthUnorderedArray() {

        double[] sampleGradesFloat = {12.3, 50.0, 95.0, 68.0, 80.0, 90.5, 93.2, 99.9, 88.0, 72.0};

        double median = Q6.calculateMedian(sampleGradesFloat);

        assertEquals("Wrong median for array {12.3, 50.0, 95.0, 68.0, 80.0, 90.5, 93.2, 99.9, 88.0, 72.0}.", 84.0, median, DELTA);

        grade += 0.1;

    }

    @Test
    public void testQ6MedianInOddLengthUnorderedArray() {

        double[] sampleGradesFloat = {95.5, 35.5, 64.5, 45.0, 52.5};
        
        double median = Q6.calculateMedian(sampleGradesFloat);
        
        assertEquals("Wrong median for array {95.5, 35.5, 52.5, 64.5, 45.0}.", 52.5, median, DELTA);
        
        grade += 0.1;
        
    }

    @Test
    public void testQ6MedianInSkewedDistributionRightEvenLength() {

        double[] sampleGradesFloat = {0.0, 1.2, 98.0, 2.0, 3.0, 67.9, 98.0, 98.0};
        
        double median = Q6.calculateMedian(sampleGradesFloat);
        
        assertEquals("Wrong median for array {95.5, 35.5, 52.5, 64.5, 45.0}.", 35.45, median, DELTA);
        
        grade += 0.1;
        
    }

    @Test
    public void testQ6MedianInSkewedDistributionLeftOddLength() {

        double[] sampleGradesFloat = {0.0, 1.2, 8.0, 123.5, 8.9, 8.0, 8.0};
        
        double median = Q6.calculateMedian(sampleGradesFloat);
        
        assertEquals("Wrong median for array {95.5, 35.5, 52.5, 64.5, 45.0}.", 8.0, median, DELTA);
        
        grade += 0.1;
        
    }

    @Test
    public void testQ6MedianInSkewedDistributionLeftEvenLength() {

        double[] sampleGradesFloat = {0.0, 1.2, 6.0, 123.5, 8.9, 6.0, 6.0, 7.0};
        
        double median = Q6.calculateMedian(sampleGradesFloat);
        
        assertEquals("Wrong median for array {95.5, 35.5, 52.5, 64.5, 45.0}.", 6.0, median, DELTA);
        
        grade += 0.1;
        
    }


    public static void main(String[] args) {

        TestUtils.runClass(TestL1Q6.class);
        
    }
    
}
